#include <iostream>

int main() {
    int x = 45;
    int y = x * 0.324;
    std::cout << y << std::endl;
};